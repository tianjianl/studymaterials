document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('tab1')
          .addEventListener('click', function chooseTab('1');
});
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('tab2')
          .addEventListener('click', function chooseTab('2');
});
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('tab3')
          .addEventListener('click', function chooseTab('3'));
});
