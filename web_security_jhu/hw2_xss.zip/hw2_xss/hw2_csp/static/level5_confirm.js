setTimeout(function() { window.location = 'welcome'; }, 5000);

